$(document).ready(function() {  
  $('#tabs li a:first').addClass('active');
  $('.container').hide();
  $('.container:first').show();
  $('#tabs li a').click(function(){
      var t = $(this).attr('href');
      $('#tabs li a').removeClass('active');        
      $(this).addClass('active');
      $('.components-container .container').hide();
      $(t).fadeIn('slow');
      return false;
  })
  
  if($(this).hasClass('active')){ //this is the start of our condition 
      $('#tabs li a').removeClass('active');         
      $(this).addClass('active');
      $('.container').hide();
      $(t).fadeIn('slow');    
  }
  });
  