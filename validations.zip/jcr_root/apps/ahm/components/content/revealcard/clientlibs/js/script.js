$(window).load(function(){
	$(".detail-name").each(function() {
		
		var panelFront = $(this).closest(".panel-front");
		var panelBack  = $(this).closest(".panel-front").next();

		if($(this).height()> 30){
			$(this).closest(".panel-details").height(95);
			panelFront.height(305);
			panelBack.height(305);
			panelBack.find(".panel-details").height(95);
	}
	  });
    
	});

