/*
 * ADOBE CONFIDENTIAL
 *
 * Copyright 2015 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 */
(function(window, $, Granite) {
    "use strict";

    var NON_VALID_CHARS = "%/\\:*?\"[]|\n\t\r. ";
    var nodePName, nodePValue = "";
    var sameNodePresent = false;
    $(window).adaptTo("foundation-registry").register("foundation.validation.validator", {
        selector: "[data-foundation-validation~='foundation.jcr.name'],[data-validation~='foundation.jcr.name']",
        validate: function(el) {
            var v = el.value;

            for (var i = 0, ln = v.length; i < ln; i++) {
                if (NON_VALID_CHARS.indexOf(v[i]) >= 0 || v.charCodeAt(i) > 127) {
                    return Granite.I18n.get("Invalid character asdsad '{0}'. It must be a valid JCR name.", [ v[i] ]);
                }
            }

             nodePValue = el.value.toString();


                sameNodePresent = false;

                $.ajax({
                    url: "/bin/querybuilder.json?type=cq:Paget&path=/content/experience-fragments&1_property=sling:resourceType&1_property.value=cq/experience-fragments/components/experiencefragment&1_property.operation=like&p.limit=-1&orderby:path",
                    contentType: "application/json",
                    dataType: 'json',
                    async: false,
                    success: function(result) {

                        for (var i = 0; i < result.hits.length; i++) {
                            nodePName = result.hits[i].path.toString();
                            nodePName=nodePName.replace("/jcr:content", "");
							nodePName=nodePName.substr(nodePName.lastIndexOf('/') + 1)
                            if (nodePValue == nodePName) {
                                sameNodePresent = true;
                                break;

                            }
                        }
                    }
                })

            if (sameNodePresent) {
                return Granite.I18n.get("Duplicate experience fragment name.");
            }
        }
    });
})(window, Granite.$, Granite);