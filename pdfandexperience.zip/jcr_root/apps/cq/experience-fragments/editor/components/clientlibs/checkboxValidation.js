(function ($, $document) {
    "use strict";
    $document.on("dialog-ready", function() {
       var checkbox = document.querySelector(".isGoal");
        var activityType = document.querySelector(".activity").parentElement.parentElement;

         if(checkbox.checked){
             activityType.style.display="block";

         }else{
             activityType.style.display="none";

         }
    });
     $document.on("change", function() {
        var checkbox = document.querySelector(".isGoal");
        var activityType = document.querySelector(".activity").parentElement.parentElement;

         if(checkbox.checked){
             activityType.style.display="block";

         }else{
             activityType.style.display="none";

         }

    });
})($, $(document));