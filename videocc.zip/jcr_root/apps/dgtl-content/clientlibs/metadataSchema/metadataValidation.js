(function (document, $) {
    "use strict";


    $(document).on("foundation-contentloaded", function (e) {
        $(".coral-Textfield").change(function(){
var a = $(this).val().trim();
$(this)[0].value = a;

});
    });



})(document, Granite.$);