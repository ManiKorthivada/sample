(function ($, $document) {

    $(document).on('dialog-ready',function(){

        $('.coral3-Button.coral3-Button--secondary:contains(Add)').text('Add Answer');

        var count = $('.coral3-Multifield-item').length;
        if (count == 0){

            $('.coral3-Button.coral3-Button--secondary:contains(Add)').click();

            var waitForEl = function(selector, callback) {

                if ($(".correct-answer:first").length) {

                    callback();
                }
                else {

                    setTimeout(function() {

                        waitForEl($(".correct-answer:first"), callback);
                    }, 100);
                }
            };

            waitForEl($(".correct-answer:first"), function() {

                $(".correct-answer:first").click();
            });

            $('.coral3-Button.coral3-Button--secondary:contains(Add)').click();
        }
        else if (count == 1){

            $('.coral3-Button.coral3-Button--secondary:contains(Add)').click();
        }
    });

    $document.on("click", ".coral3-Icon.coral3-Icon--sizeS.coral3-Icon--delete", function(){

        if($(".correct-answer:checked").length == 0){

            $(".correct-answer:first").click();
        }

        if($(".coral3-Multifield-item").length <2){

            $('.coral3-Button.coral3-Button--secondary:contains(Add)').click();
        }
    });

    $document.on("change", ".correct-answer", function() {

        $('.correct-answer').each(function() {

            $(this).prop('checked', false);
        });

        $(this).prop('checked', true);
    });

})(jQuery, jQuery(document));