/*******************************************************************************
 * ADOBE CONFIDENTIAL
 * __________________
 *
 * Copyright 2016 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 ******************************************************************************/
"use strict";
use(function() {
    var expressionResolver = sling.getService(com.adobe.granite.ui.components.ExpressionResolver);
    var expressionHelper = new com.adobe.granite.ui.components.ExpressionHelper(expressionResolver, request);
    return {
        path: expressionHelper.getString(properties.get("path"))
    }
});