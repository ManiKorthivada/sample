(function (document, $) {
    "use strict";
 $(document).on("click", ".coral-Tab", function(){

     $('.coral-RichText-editable').click();

 });


    $(document).on("change", ".coral-RichText-editable", function(){
        var a = $(".coral-RichText-editable").text();
        if ($.trim(a) === ''){
				$(".coral-RichText-editable").css("position", "relative").addClass("is-invalid");
            $('.coral-RichText-editable').text('Please enter some text.');

            $(".is-selected").addClass("is-invalid");
                return false;
        }

    });

$(document).on("focus", ".coral-RichText-editable", function(){
    var b = $(".coral-RichText-editable").text();
 if (b === 'Please enter some text.')
 {
$('.coral-RichText-editable').text('');

 }
});

     $(document).on("click", ".coral-Icon--check", function(){

var c = $(".coral-RichText-editable").text();
         if ((c === 'Please enter some text.')){

             return false;
         }
     });



})(document, Granite.$);
